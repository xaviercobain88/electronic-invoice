@javax.xml.bind.annotation.XmlSchema(namespace = "http://ec.gob.sri.ws.recepcion")
package recepcion.ws.sri.gob.ec;
