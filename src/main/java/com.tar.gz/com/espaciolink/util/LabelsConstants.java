package com.espaciolink.util;

public class LabelsConstants {
	public static final String NAME="labels";
	public static final String COMBOBOX_SELECCIONE="combobox_seleccione";
	
}
