@javax.xml.bind.annotation.XmlSchema(namespace = "http://ec.gob.sri.ws.autorizacion")
package autorizacion.ws.sri.gob.ec;
